package com.techhub.oops.inheritance;

/**
 * The Maruti800 class
 * 
 * @author ramniwash
 */
public class Maruti800 extends Maruti {

	@Override
	public String toString() {
		return "This is Maruti800";
	}
}
