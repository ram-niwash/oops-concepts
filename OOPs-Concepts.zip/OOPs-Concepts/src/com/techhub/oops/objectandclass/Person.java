package com.techhub.oops.objectandclass;

import java.util.Date;

/**
 * The Person Class
 * 
 * @author ramniwash
 *
 */
public class Person {

	/** The name of Person state (fields,data) */
	private String name;

	/** The dateOfBirth of Person state (fields,data) */
	private Date dateOfBirth;

	/** The permanentAddress of Person state (fields,data) */
	private Address permanentAddress;

	/** The get behaviour(Code) for name */
	public String getName() {
		return name;
	}

	/** The set behaviour(Code) for name */
	public void setName(String name) {
		this.name = name;
	}

	/** The get behaviour(Code) for dateOfBirth */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/** The set behaviour(Code) for dateOfBirth */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/** The get behaviour(Code) for permanentAddress */
	public Address getPermanentAddress() {
		return permanentAddress;
	}

	/** The set behaviour(Code) for permanentAddress */
	public void setPermanentAddress(Address permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", dateOfBirth=" + dateOfBirth + ", permanentAddress=" + permanentAddress + "]";
	}
}
